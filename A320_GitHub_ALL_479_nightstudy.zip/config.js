// Paste your Supabase Project URL and anon/public key here.
// These are safe to expose in a browser app when Row Level Security is enabled.
window.SUPABASE_URL = "YOUR_SUPABASE_URL";
window.SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
