
(() => {
  const localKey="a320-study-progress-v2";
  const ratings=JSON.parse(localStorage.getItem(localKey)||"{}");
  const state={mode:"study",topic:null,user:null,supabase:null,ratings};

  const sections=[...document.querySelectorAll(".topicSection")];
  const topicInfo=sections.map((s,i)=>({
    el:s, name:s.querySelector(".topicHeading h2")?.textContent.trim()||`Topic ${i+1}`,
    count:s.querySelectorAll(".card").length
  }));
  state.topic=topicInfo[0]?.name||null;

  function saveLocal(){ localStorage.setItem(localKey,JSON.stringify(state.ratings)); }
  function counts(cards){
    const c={again:0,almost:0,got:0};
    cards.forEach(card=>{const s=state.ratings[card.dataset.key]; if(s)c[s]++});
    return c;
  }
  function bar(c,n){return `<div class="track"><span class="segAgain" style="width:${n?c.again/n*100:0}%"></span><span class="segAlmost" style="width:${n?c.almost/n*100:0}%"></span><span class="segGot" style="width:${n?c.got/n*100:0}%"></span></div>`}
  function renderSummary(){
    const cards=[...document.querySelectorAll(".card")];
    const c=counts(cards), rated=c.again+c.almost+c.got;
    document.getElementById("summary").innerHTML=`<div class="summary"><div class="metric"><div class="label">Overall rated</div><div class="big">${rated} / ${cards.length}</div>${bar(c,cards.length)}</div><div class="metric"><div class="label">Again / Almost / Got it</div><div class="big">${c.again} · ${c.almost} · ${c.got}</div></div></div>`;
  }
  function renderTabs(){
    const root=document.getElementById("topicTabs"); root.innerHTML="";
    topicInfo.forEach(t=>{
      const b=document.createElement("button"); b.className="topicBtn"+(t.name===state.topic?" active":"");
      b.innerHTML=`${t.name}<small>${t.count} cards</small>`;
      b.onclick=()=>{state.topic=t.name;state.mode="study";render();};
      root.appendChild(b);
    });
  }
  function applyRatings(){
    document.querySelectorAll(".card").forEach(card=>{
      const s=state.ratings[card.dataset.key]||""; card.dataset.status=s;
      card.querySelectorAll(".emoji").forEach(b=>b.classList.toggle("active",b.dataset.type===s));
    });
  }
  async function pushOne(cardKey,rating){
    if(!state.user||!state.supabase)return;
    if(!rating){
      await state.supabase.from("progress").delete().eq("user_id",state.user.id).eq("card_key",cardKey);
    }else{
      await state.supabase.from("progress").upsert({user_id:state.user.id,card_key:cardKey,rating,updated_at:new Date().toISOString()},{onConflict:"user_id,card_key"});
    }
  }
  document.querySelectorAll(".emoji").forEach(b=>b.addEventListener("click",async()=>{
    const card=b.closest(".card"),k=card.dataset.key,v=b.dataset.type;
    state.ratings[k]=state.ratings[k]===v?"":v; if(!state.ratings[k])delete state.ratings[k];
    saveLocal(); applyRatings(); renderSummary(); await pushOne(k,state.ratings[k]||null);
  }));

  function renderReview(){
    const panel=document.getElementById("reviewPanel"); let html="";
    [["again","😵 Again"],["almost","🤔 Almost"],["got","😎 Got it"]].forEach(([type,label])=>{
      const cards=[...document.querySelectorAll(".card")].filter(c=>state.ratings[c.dataset.key]===type);
      html+=`<div class="reviewHead"><span>${label}</span><span>${cards.length}</span></div><div class="cards">${cards.map(c=>c.outerHTML).join("")||'<div class="label">Nothing here yet.</div>'}</div>`;
    });
    panel.innerHTML=html;
    panel.querySelectorAll(".emoji").forEach(b=>b.onclick=async()=>{
      const card=b.closest(".card"),k=card.dataset.key,v=b.dataset.type;
      state.ratings[k]=state.ratings[k]===v?"":v;if(!state.ratings[k])delete state.ratings[k];
      saveLocal();await pushOne(k,state.ratings[k]||null);render();
    });
  }
  function renderProgress(){
    const panel=document.getElementById("progressPanel");
    panel.innerHTML='<div class="metric">'+topicInfo.map(t=>{
      const cards=[...t.el.querySelectorAll(".card")],c=counts(cards),r=c.again+c.almost+c.got;
      return `<div class="progressRow"><b>${t.name}</b>${bar(c,cards.length)}<span class="label">${r}/${cards.length} · 😵${c.again} 🤔${c.almost} 😎${c.got}</span></div>`;
    }).join("")+'</div>';
  }
  function render(){
    renderTabs();applyRatings();renderSummary();
    document.querySelectorAll(".toolBtn[data-mode]").forEach(b=>b.classList.toggle("active",b.dataset.mode===state.mode));
    sections.forEach(s=>{
      const name=s.querySelector(".topicHeading h2")?.textContent.trim();
      s.classList.toggle("active",(state.mode==="study"||state.mode==="facts")&&name===state.topic);
      const study=s.querySelector(".studyView"),facts=s.querySelector(".factsView");
      if(study)study.classList.toggle("hidden",state.mode==="facts");
      if(facts)facts.classList.toggle("active",state.mode==="facts");
    });
    document.getElementById("reviewPanel").classList.toggle("active",state.mode==="review");
    document.getElementById("progressPanel").classList.toggle("active",state.mode==="progress");
    if(state.mode==="review")renderReview();
    if(state.mode==="progress")renderProgress();
  }

  document.querySelectorAll(".toolBtn[data-mode]").forEach(b=>b.onclick=()=>{state.mode=b.dataset.mode;render();});
  document.getElementById("resetBtn").onclick=async()=>{
    if(!confirm("Reset all ratings for this account/device?"))return;
    state.ratings={};localStorage.removeItem(localKey);
    if(state.user&&state.supabase) await state.supabase.from("progress").delete().eq("user_id",state.user.id);
    render();
  };

  const modal=document.getElementById("loginModal"),loginBtn=document.getElementById("loginBtn");
  loginBtn.onclick=async()=>{
    if(state.user){
      if(confirm(`Sign out ${state.user.email}?`)){await state.supabase.auth.signOut();}
    }else{modal.classList.add("open");modal.setAttribute("aria-hidden","false");}
  };
  document.getElementById("closeModal").onclick=()=>{modal.classList.remove("open");modal.setAttribute("aria-hidden","true");};

  async function initAuth(){
    if(!window.SUPABASE_URL||!window.SUPABASE_ANON_KEY||window.SUPABASE_URL.includes("YOUR_")){
      document.getElementById("syncState").textContent="Local progress is working. Add Supabase keys in config.js to enable login + sync.";
      return;
    }
    state.supabase=window.supabase.createClient(window.SUPABASE_URL,window.SUPABASE_ANON_KEY);
    async function onUser(user){
      state.user=user||null;
      loginBtn.textContent=user?`☁️ ${user.email.split("@")[0]}`:"Sign in";
      if(!user){document.getElementById("syncState").textContent="Progress saves on this device. Sign in to sync across iPads.";return;}
      document.getElementById("syncState").textContent="Signed in · syncing progress…";
      const {data,error}=await state.supabase.from("progress").select("card_key,rating").eq("user_id",user.id);
      if(!error&&data){
        data.forEach(x=>state.ratings[x.card_key]=x.rating);
        saveLocal();render();
        document.getElementById("syncState").textContent="☁️ Progress synced to your account.";
      }else document.getElementById("syncState").textContent="Signed in, but progress sync needs the database table from supabase.sql.";
    }
    const {data:{session}}=await state.supabase.auth.getSession(); await onUser(session?.user);
    state.supabase.auth.onAuthStateChange((_event,session)=>onUser(session?.user));
    document.getElementById("magicLinkBtn").onclick=async()=>{
      const email=document.getElementById("emailInput").value.trim(),msg=document.getElementById("authMsg");
      if(!email){msg.textContent="Enter your email first.";return;}
      msg.textContent="Sending…";
      const redirect=window.location.href.split("#")[0];
      const {error}=await state.supabase.auth.signInWithOtp({email,options:{emailRedirectTo:redirect}});
      msg.textContent=error?error.message:"Check your email ✨ Tap the sign-in link and you’ll come straight back here.";
    };
  }
  initAuth();render();
})();
