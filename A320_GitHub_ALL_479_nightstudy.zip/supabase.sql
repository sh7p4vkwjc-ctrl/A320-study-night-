-- Run this once in Supabase SQL Editor.
create table if not exists public.progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  card_key text not null,
  rating text not null check (rating in ('again','almost','got')),
  updated_at timestamptz not null default now(),
  primary key (user_id, card_key)
);

alter table public.progress enable row level security;

create policy "Users can read own progress"
on public.progress for select
using (auth.uid() = user_id);

create policy "Users can insert own progress"
on public.progress for insert
with check (auth.uid() = user_id);

create policy "Users can update own progress"
on public.progress for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "Users can delete own progress"
on public.progress for delete
using (auth.uid() = user_id);
