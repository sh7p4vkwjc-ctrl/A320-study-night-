# A320 Night Study Deck

This is a static, iPad-friendly PWA. It works on GitHub Pages, Netlify, Cloudflare Pages, Vercel static hosting, etc.

## Why login uses Supabase
GitHub Pages is static hosting, so it cannot securely store separate progress for different people by itself.
Supabase provides:
- passwordless email magic-link login
- one private progress record per signed-in user
- sync across iPhone/iPad/browser
- Row Level Security so users can only access their own ratings

## 1) Create the login/progress backend
1. Create a free Supabase project.
2. Open **SQL Editor** and run `supabase.sql`.
3. Open **Authentication > URL Configuration**.
4. Add your final GitHub Pages URL as a Redirect URL, for example:
   `https://YOURNAME.github.io/a320-study/`
5. In **Project Settings > API**, copy:
   - Project URL
   - anon/public key
6. Paste them into `config.js`.

Do NOT use the service-role key in this website.

## 2) GitHub Pages version
1. Create a GitHub repository, for example `a320-study`.
2. Upload every file/folder from this project.
3. Commit to `main`.
4. GitHub > repository **Settings > Pages** > Source: **GitHub Actions**.
5. The included workflow deploys the app.

## 3) iPad / iPhone
Open the deployed HTTPS URL in Safari.
For app-like use:
**Share > Add to Home Screen**.

The app stores progress locally even without signing in.
After sign-in, progress is stored per Supabase user and syncs across devices.


## Current study content

This build contains **479 source-backed cards**:
- Abnormal Procedure — 24
- Aircraft Systems ATA 20–27 — 76
- Aircraft Systems ATA 28–70 — 133
- Ops Specs / Performance / Limitations — 29
- Special Operations — 44 (LVO Q1–20 + PBN Q21–44, kept together)
- Adverse Weather — 173 source-screenshot cards from the uploaded screen recording

**Normal Procedure is not included yet because no Normal Procedure source has been uploaded.**
The app intentionally does not invent missing aviation questions.

For the Adverse Weather recording, source screenshots are preserved on the individual cards so the original marked correct answers remain visible.
